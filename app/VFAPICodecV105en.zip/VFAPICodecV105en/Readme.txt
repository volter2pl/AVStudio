                        =======================================
                                VFAPI Reader Codec 1.05
                                        English
                        =======================================



This is an english translation of the latest version of the VFAPI Reader Codec.

To install, just run vifpset.bat. You must do this before using VFAPIConvEN.exe.


Note: I didnt coded this program, I have only done the translation. To find out how 
      to contact the real author, read Readme2.txt.


   -KiinG <kiing@freelsd.tv>